CREATE DEFINER=`Skadi`@`%` PROCEDURE `TRYCLAIMNAME`(
	VALUE_FactionName CHAR(100),
    VALUE_FactionUUID CHAR(100),
    VALUE_FactionNameCap CHAR(100),
    VALUE_Boolean DOUBLE
)
BEGIN
	IF EXISTS (SELECT * FROM FactionName WHERE FactionName=VALUE_FactionName) THEN
		SET VALUE_Boolean = 1;
        SELECT VALUE_Boolean;
    ELSE
		INSERT IGNORE INTO FactionName (FactionName,FactionUUID) VALUES (VALUE_FactionName,VALUE_FactionUUID);
        UPDATE FactionName SET FactionNameCap=VALUE_FactionNameCap WHERE FactionUUID=VALUE_FactionUUID;
		SET VALUE_Boolean = 0;
        SELECT VALUE_Boolean;
	END IF;
END